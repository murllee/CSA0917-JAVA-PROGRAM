CREATE DATABASE IF NOT EXISTS transport_test;
USE transport_test;
DROP TABLE IF EXISTS users;
CREATE TABLE users (
    username VARCHAR(30) PRIMARY KEY,
    password VARCHAR(60) NOT NULL        -- plain text ONLY for this classroom demo; real systems store salted hashes
);
INSERT INTO users VALUES ('alice','alice@123'), ('admin','S3cret!Adm');
