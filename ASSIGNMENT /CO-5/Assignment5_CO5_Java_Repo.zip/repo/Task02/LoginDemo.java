import java.sql.*;

/**
 * Task B2 - unsafe vs safe login. Run with no arguments to print the SQL that each version builds;
 * run with  <jdbcUrl> <user> <password>  to execute both against the local test database.
 */
public class LoginDemo {
    // UNSAFE: user input is concatenated into the SQL text.
    static String unsafeSql(String u, String p) {
        return "SELECT * FROM users WHERE username = '" + u + "' AND password = '" + p + "'";
    }
    static boolean unsafeLogin(Connection c, String u, String p) throws SQLException {
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery(unsafeSql(u, p))) {
            return rs.next();
        }
    }
    // SAFE: SQL text is fixed; input travels only as bound parameters.
    static boolean safeLogin(Connection c, String u, String p) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("SELECT * FROM users WHERE username = ? AND password = ?")) {
            ps.setString(1, u); ps.setString(2, p);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        }
    }

    public static void main(String[] a) throws Exception {
        String[][] tests = {
            {"alice", "alice@123"},          // valid login
            {"alice", "wrong"},              // invalid password
            {"admin' -- ", "anything"},      // comment attack: password check removed
            {"x' OR '1'='1", "x' OR '1'='1"} // tautology attack: condition always true
        };
        System.out.println("=== SQL text built by the UNSAFE version ===");
        for (String[] t : tests) System.out.println("user=[" + t[0] + "] pass=[" + t[1] + "]\n   -> " + unsafeSql(t[0], t[1]));
        System.out.println("\n=== SQL text sent by the SAFE version (always the same) ===");
        System.out.println("SELECT * FROM users WHERE username = ? AND password = ?");
        if (a.length == 3) {
            try (Connection c = DriverManager.getConnection(a[0], a[1], a[2])) {
                System.out.printf("%n%-24s %-10s %-10s%n", "Input (user)", "Unsafe", "Safe");
                for (String[] t : tests)
                    System.out.printf("%-24s %-10s %-10s%n", t[0], unsafeLogin(c, t[0], t[1]) ? "LOGIN OK" : "rejected",
                            safeLogin(c, t[0], t[1]) ? "LOGIN OK" : "rejected");
            }
        } else System.out.println("\n(No database arguments given - only query text shown.)");
    }
}
