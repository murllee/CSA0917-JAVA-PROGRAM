/** Explains WHY a line is damaged (used for adversarial testing and migration reports). */
public class Validator {
    public static String reason(String line) {
        if (line == null || line.isBlank()) return "empty line";
        String[] f = line.split(",", -1);
        if (f.length != 7) return "wrong field count (" + f.length + " instead of 7)";
        if (!f[0].trim().matches("P\\d+")) return "bad pass id '" + f[0] + "'";
        if (!f[1].trim().matches("\\d+")) return "non-numeric register number";
        if (f[2].isBlank() || f[4].isBlank()) return "missing name or stop";
        try { Integer.parseInt(f[3].trim()); } catch (NumberFormatException e) { return "non-numeric route"; }
        try { java.time.LocalDate.parse(f[5].trim()); } catch (Exception e) { return "invalid validity date '" + f[5] + "'"; }
        try { if (Double.parseDouble(f[6].trim()) < 0) return "negative amount"; }
        catch (NumberFormatException e) { return "non-numeric amount '" + f[6] + "'"; }
        return null;   // valid
    }
}
