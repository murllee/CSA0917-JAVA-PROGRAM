import java.nio.file.*;
import java.util.*;

public class DamagedDataTest {
    public static void main(String[] a) throws Exception {
        List<String> lines = List.of(
            "P2001,2310011,Ravi,5,Porur,2026-12-31,1400.00",        // T1 valid
            "P2002,2310012,Sita,5,Porur,2026-12-31",                // T2 wrong field count (6)
            "P2003,2310013,Hari,5,Porur,2026-12-31,1400.00,EXTRA",  // T3 wrong field count (8)
            "P2004,2310014,Lata,5,Porur,2026-12-31,ABC",            // T4 non-numeric amount
            "",                                                     // T5 empty line
            "P2006,2310016,Gopi,5,Porur,2026-13-45,1400.00",        // T6 impossible date
            "P2007,2310017,Nila,5,Porur,2026-12-31,-50.00",         // T7 negative amount
            "P2008,2310018,Omar,5,Porur,2026-12-31,1400.00");       // T8 valid
        Files.write(Paths.get("damaged_passes.txt"), lines);
        System.out.printf("%-4s %-62s %-10s %s%n", "No", "Input line", "Result", "Reason");
        int ok = 0;
        for (int i = 0; i < lines.size(); i++) {
            String why = Validator.reason(lines.get(i));
            Pass p = Pass.parse(lines.get(i));
            if (p != null) ok++;
            String shown = lines.get(i).isEmpty() ? "(empty line)" : lines.get(i);
            System.out.printf("T%-3d %-62s %-10s %s%n", i + 1, shown, p == null ? "REJECTED" : "ACCEPTED", why == null ? "-" : why);
        }
        System.out.println("Accepted " + ok + " of " + lines.size() + " lines; program did not crash.");
        PassStore s = new PassStore("damaged_passes.txt");
        System.out.println("find(P2008) after 6 damaged lines = " + s.find("P2008") + "  (damaged skipped: " + s.damagedSeen + ")");
    }
}
