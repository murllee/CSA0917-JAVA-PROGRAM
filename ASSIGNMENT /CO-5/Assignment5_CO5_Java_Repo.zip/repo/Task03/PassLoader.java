import java.sql.*;
import java.time.LocalDate;
import java.util.*;

/**
 * Task B3 - JDBC performance comparison.
 * Usage: java -cp .;mysql-connector-j.jar PassLoader <jdbcUrl> <user> <password>
 * Url example: jdbc:mysql://localhost:3306/transport_test?rewriteBatchedStatements=true
 */
public class PassLoader {
    static final int BATCH = 1000;
    static final String INS = "INSERT INTO bus_pass (pass_id,reg_no,name,route_no,boarding_stop,valid_till,amount) VALUES (?,?,?,?,?,?,?)";

    static String[] rec(int i) {          // one synthetic record as strings
        return new String[]{"P" + (100000 + i), String.valueOf(2300000 + i), "Student" + i, String.valueOf(i % 40 + 1),
                "Stop" + (i % 97), LocalDate.of(2026, 12, 31).toString(), (1000 + i % 900) + ".00"};
    }

    /** TODO 1 (completed): one Statement per row, SQL built by string concatenation. */
    static void withStatement(Connection c, int n) throws SQLException {
        try (Statement st = c.createStatement()) {
            for (int i = 1; i <= n; i++) {
                String[] r = rec(i);
                st.executeUpdate("INSERT INTO bus_pass VALUES ('" + r[0] + "','" + r[1] + "','" + r[2] + "'," + r[3]
                        + ",'" + r[4] + "','" + r[5] + "'," + r[6] + ")");
            }
        }
    }

    /** TODO 2 (completed): one PreparedStatement reused, one round trip per row. */
    static void withPrepared(Connection c, int n) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(INS)) {
            for (int i = 1; i <= n; i++) {
                bind(ps, rec(i));
                ps.executeUpdate();
            }
        }
    }

    /** TODO 3 (completed): PreparedStatement + addBatch(), executeBatch() every 1000 rows. */
    static void withBatch(Connection c, int n) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(INS)) {
            for (int i = 1; i <= n; i++) {
                bind(ps, rec(i));
                ps.addBatch();
                if (i % BATCH == 0) ps.executeBatch();
            }
            ps.executeBatch();                       // remaining rows
        }
    }

    static void bind(PreparedStatement ps, String[] r) throws SQLException {
        ps.setString(1, r[0]); ps.setString(2, r[1]); ps.setString(3, r[2]);
        ps.setInt(4, Integer.parseInt(r[3])); ps.setString(5, r[4]);
        ps.setDate(6, java.sql.Date.valueOf(r[5])); ps.setString(7, r[6]);
    }

    static void clear(Connection c) throws SQLException {
        try (Statement st = c.createStatement()) { st.executeUpdate("DELETE FROM bus_pass"); }
    }
    static int count(Connection c) throws SQLException {
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM bus_pass")) {
            rs.next(); return rs.getInt(1);
        }
    }

    /** Verify the table with SELECT + ResultSetMetaData. */
    static void describe(Connection c) throws SQLException {
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT * FROM bus_pass ORDER BY pass_id LIMIT 10")) {
            ResultSetMetaData md = rs.getMetaData();
            for (int i = 1; i <= md.getColumnCount(); i++)
                System.out.printf("  col %d: %-14s %-10s size=%d%n", i, md.getColumnName(i), md.getColumnTypeName(i), md.getColumnDisplaySize(i));
            while (rs.next()) {
                StringBuilder sb = new StringBuilder("  ");
                for (int i = 1; i <= md.getColumnCount(); i++) sb.append(rs.getString(i)).append(i < md.getColumnCount() ? " | " : "");
                System.out.println(sb);
            }
        }
    }

    /** Transaction with a deliberate failure halfway: an invalid amount is bound as text. */
    static void transactionDemo(Connection c, int n, boolean useTransaction) throws SQLException {
        clear(c);
        c.setAutoCommit(!useTransaction);
        try (PreparedStatement ps = c.prepareStatement(INS)) {
            for (int i = 1; i <= n; i++) {
                String[] r = rec(i);
                if (i == n / 2) r[6] = "ABC";                         // invalid amount halfway
                bind(ps, r);
                ps.executeUpdate();
            }
            if (useTransaction) c.commit();
        } catch (SQLException e) {
            System.out.println("  failure at row " + (n / 2) + ": " + e.getMessage());
            if (useTransaction) c.rollback();
        } finally {
            c.setAutoCommit(true);
        }
        System.out.println("  rows in table afterwards (" + (useTransaction ? "single transaction" : "auto-commit") + "): " + count(c));
    }

    interface Job { void run(Connection c, int n) throws SQLException; }

    static long time(Connection c, int n, Job j) throws SQLException {
        clear(c);
        long t0 = System.nanoTime();
        j.run(c, n);
        return (System.nanoTime() - t0) / 1_000_000;
    }

    public static void main(String[] a) throws Exception {
        try (Connection c = DriverManager.getConnection(a[0], a[1], a[2])) {
            DatabaseMetaData dm = c.getMetaData();
            System.out.println("Connected: " + dm.getDatabaseProductName() + " " + dm.getDatabaseProductVersion());

            System.out.println("\n[1] Insert 10 records with each approach");
            withStatement(c, 10); System.out.println("Statement rows: " + count(c));
            clear(c); withPrepared(c, 10); System.out.println("PreparedStatement rows: " + count(c));
            clear(c); withBatch(c, 10); System.out.println("Batch rows: " + count(c));
            describe(c);

            System.out.println("\n[2] Timing (ms)");
            System.out.printf("%-10s %-12s %-18s %-8s%n", "Records", "Statement", "PreparedStatement", "Batch");
            for (int n : new int[]{1000, 10000, 100000}) {
                long t1 = time(c, n, PassLoader::withStatement);
                long t2 = time(c, n, PassLoader::withPrepared);
                long t3 = time(c, n, PassLoader::withBatch);
                System.out.printf("%-10d %-12d %-18d %-8d%n", n, t1, t2, t3);
            }

            System.out.println("\n[3] Auto-commit vs one transaction, 1000 rows, 1 bad row halfway");
            transactionDemo(c, 1000, false);
            transactionDemo(c, 1000, true);
        }
    }
}
