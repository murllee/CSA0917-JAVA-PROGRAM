CREATE DATABASE IF NOT EXISTS transport_test;
USE transport_test;
DROP TABLE IF EXISTS bus_pass;
CREATE TABLE bus_pass (
    pass_id       VARCHAR(10)   PRIMARY KEY,
    reg_no        VARCHAR(12)   NOT NULL,
    name          VARCHAR(60)   NOT NULL,
    route_no      INT           NOT NULL,
    boarding_stop VARCHAR(40)   NOT NULL,
    valid_till    DATE          NOT NULL,
    amount        DECIMAL(8,2)  NOT NULL,
    INDEX idx_route (route_no)
) ENGINE=InnoDB;
