import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

/**
 * Task B4 - migrate passes.txt into MySQL using batches and ONE transaction.
 * java MigrationTool <passFile> --dry-run                     (validation only, no database)
 * java MigrationTool <passFile> <jdbcUrl> <user> <password>   (full migration)
 */
public class MigrationTool {
    static final int BATCH = 1000;
    static final String INS = "INSERT INTO bus_pass (pass_id,reg_no,name,route_no,boarding_stop,valid_till,amount) VALUES (?,?,?,?,?,?,?)";

    public static void main(String[] a) throws Exception {
        List<Pass> good = new ArrayList<>();
        List<String> bad = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        long t0 = System.nanoTime();
        int lineNo = 0;
        try (BufferedReader br = Files.newBufferedReader(Paths.get(a[0]), StandardCharsets.UTF_8)) {
            String line;
            while ((line = br.readLine()) != null) {
                lineNo++;
                String why = Validator.reason(line);
                Pass p = why == null ? Pass.parse(line) : null;
                if (p != null && !seen.add(p.passId)) { p = null; why = "duplicate pass id " + line.split(",")[0]; }
                if (p == null) bad.add("line " + lineNo + ": " + why + "  -> [" + line + "]"); else good.add(p);
            }
        }
        double readMs = (System.nanoTime() - t0) / 1e6;
        System.out.printf("Read %d lines in %.1f ms: %d valid, %d rejected%n", lineNo, readMs, good.size(), bad.size());
        System.out.println("--- Validation failures ---");
        for (int i = 0; i < Math.min(bad.size(), 20); i++) System.out.println(bad.get(i));
        if (bad.size() > 20) System.out.println("... and " + (bad.size() - 20) + " more");
        if (a.length < 4) { System.out.println("(dry run - database not touched)"); return; }

        try (Connection c = DriverManager.getConnection(a[1], a[2], a[3])) {
            DatabaseMetaData dm = c.getMetaData();
            System.out.println("Database product : " + dm.getDatabaseProductName() + " " + dm.getDatabaseProductVersion());
            System.out.println("Driver           : " + dm.getDriverName() + " " + dm.getDriverVersion());
            System.out.print("Tables           : ");
            try (ResultSet rs = dm.getTables(c.getCatalog(), null, "%", new String[]{"TABLE"})) {
                while (rs.next()) System.out.print(rs.getString("TABLE_NAME") + " ");
            }
            System.out.println();

            c.setAutoCommit(false);                          // ONE transaction for the whole migration
            long t1 = System.nanoTime();
            try (PreparedStatement ps = c.prepareStatement(INS)) {
                int n = 0;
                for (Pass p : good) {
                    ps.setString(1, p.passId); ps.setString(2, p.regNo); ps.setString(3, p.name);
                    ps.setInt(4, p.route); ps.setString(5, p.stop);
                    ps.setDate(6, java.sql.Date.valueOf(p.validTill)); ps.setBigDecimal(7, java.math.BigDecimal.valueOf(p.amount));
                    ps.addBatch();
                    if (++n % BATCH == 0) ps.executeBatch();
                }
                ps.executeBatch();
                c.commit();
                System.out.printf("Committed %d rows in %.1f ms%n", good.size(), (System.nanoTime() - t1) / 1e6);
            } catch (SQLException e) {
                c.rollback();                                // nothing half-migrated
                System.out.println("Migration FAILED, rolled back: " + e.getMessage());
            }
        }
    }
}
