import java.io.*;
import java.util.*;

/** Expansion scenario: 8,000 passes now vs 100x = 800,000. Measures scan search, HashMap load and heap. */
public class ScaleCheck {
    static long usedMB() { Runtime r = Runtime.getRuntime(); return (r.totalMemory() - r.freeMemory()) / (1024 * 1024); }
    public static void main(String[] a) throws Exception {
        System.out.println("n,fileMB,worstCaseScanMs,mapLoadMs,mapLookupMicros,mapHeapMB");
        for (int n : new int[]{8000, 800000}) {
            String f = "scale_" + n + ".txt";
            try (BufferedWriter w = new BufferedWriter(new FileWriter(f), 1 << 16)) {
                for (int i = 1; i <= n; i++)
                    w.write("P" + (1000 + i) + "," + (2300000 + i) + ",Student" + i + "," + (i % 40 + 1) + ",Stop" + (i % 97) + ",2026-12-31," + (1000 + i % 900) + ".00\n");
            }
            PassStore s = new PassStore(f);
            s.find("P" + (1000 + n));                                      // warm-up
            long t0 = System.nanoTime();
            s.find("P" + (1000 + n));                                      // last record = worst-case scan
            double scanMs = (System.nanoTime() - t0) / 1e6;
            System.gc(); long before = usedMB();
            t0 = System.nanoTime(); Map<String, Pass> m = s.loadAll(); double loadMs = (System.nanoTime() - t0) / 1e6;
            long heap = Math.max(0, usedMB() - before);
            t0 = System.nanoTime(); for (int i = 0; i < 1000; i++) m.get("P" + (1000 + 1 + i)); double look = (System.nanoTime() - t0) / 1e3 / 1000;
            System.out.printf("%d,%.1f,%.1f,%.1f,%.2f,%d%n", n, new File(f).length() / 1048576.0, scanMs, loadMs, look, heap);
            new File(f).delete();
        }
    }
}
