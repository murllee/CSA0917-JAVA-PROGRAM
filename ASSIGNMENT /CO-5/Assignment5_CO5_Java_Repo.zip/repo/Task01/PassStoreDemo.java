import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDate;

public class PassStoreDemo {
    public static void main(String[] a) throws IOException {
        Files.deleteIfExists(Paths.get("passes.txt"));
        PassStore s = new PassStore("passes.txt");
        System.out.println("Test 0 (missing file): find(P1001) = " + s.find("P1001"));
        s.add(new Pass("P1001", "2310001", "Arun Kumar", 12, "Tambaram", LocalDate.parse("2026-12-31"), 1500));
        // P1002 is written damaged on purpose (6 fields instead of 7)
        Files.writeString(Paths.get("passes.txt"), "P1002,2310002,Divya,12,Guindy,2026-12-31\n",
                java.nio.file.StandardOpenOption.APPEND);
        s.add(new Pass("P1003", "2310003", "Karthik", 7, "Adyar", LocalDate.parse("2026-11-30"), 1200));
        s.add(new Pass("P1004", "2310004", "Meena", 12, "Velachery", LocalDate.parse("2027-01-15"), 1500));

        System.out.println("Test 1 (normal)     : find(P1003) = " + s.find("P1003"));
        System.out.println("Test 2 (damaged)    : find(P1002) = " + s.find("P1002")
                + "   [damaged lines skipped: " + s.damagedSeen + "]");
        System.out.println("Test 3 (absent id)  : find(P9999) = " + s.find("P9999"));
        System.out.println("Test 4 (list route 12):");
        for (Pass p : s.listByRoute(12)) System.out.println("    " + p);
        System.out.println("Test 5 (damaged lines seen during list): " + s.damagedSeen);
    }
}
