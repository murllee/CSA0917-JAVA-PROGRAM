import java.io.*;
import java.nio.file.*;
import java.util.List;

/** Measures line counting: 1-byte unbuffered, BufferedInputStream, 8 KB byte[] buffer, Files.readAllLines. */
public class LineCountBench {
    static long reads;   // number of read() calls issued to the stream

    static long unbuffered(String f) throws IOException {
        long lines = 0; reads = 0;
        try (FileInputStream in = new FileInputStream(f)) {
            int b;
            while ((b = in.read()) != -1) { reads++; if (b == '\n') lines++; }
            reads++;                                   // final -1 call
        }
        return lines;
    }
    static long bufferedStream(String f) throws IOException {
        long lines = 0; reads = 0;
        try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(f), 8192)) {
            int b;
            while ((b = in.read()) != -1) { reads++; if (b == '\n') lines++; }
        }
        return lines;
    }
    static long byteArray(String f) throws IOException {
        long lines = 0; reads = 0;
        byte[] buf = new byte[8192];
        try (FileInputStream in = new FileInputStream(f)) {
            int n;
            while ((n = in.read(buf)) != -1) {
                reads++;
                for (int i = 0; i < n; i++) if (buf[i] == '\n') lines++;
            }
        }
        return lines;
    }
    static long readAll(String f) throws IOException {
        List<String> all = Files.readAllLines(Paths.get(f));
        return all.size();
    }
    static long usedMB() { Runtime r = Runtime.getRuntime(); return (r.totalMemory() - r.freeMemory()) / (1024 * 1024); }

    static void gen(String f, long targetBytes) throws IOException {
        try (BufferedWriter w = new BufferedWriter(new FileWriter(f), 1 << 16)) {
            long written = 0; int i = 1;
            while (written < targetBytes) {
                String s = "P" + (1000 + i) + "," + (2300000 + i % 90000) + ",Student" + i + "," + (i % 40 + 1)
                        + ",Stop" + (i % 97) + ",2026-12-31," + (1000 + i % 900) + ".00\n";
                w.write(s); written += s.length(); i++;
            }
        }
    }

    public static void main(String[] a) throws Exception {
        int[] sizes = {1, 10, 50};
        System.out.println("sizeMB,method,lines,readCalls,timeMs,extraHeapMB");
        for (int mb : sizes) {
            String f = "log_" + mb + "mb.txt";
            gen(f, mb * 1024L * 1024L);
            long bytes = new File(f).length();
            for (String m : new String[]{"unbuffered-1byte", "BufferedInputStream", "byte[8192]", "readAllLines"}) {
                System.gc(); long before = usedMB();
                long t0 = System.nanoTime(); long lines;
                switch (m) {
                    case "unbuffered-1byte": lines = unbuffered(f); break;
                    case "BufferedInputStream": lines = bufferedStream(f); break;
                    case "byte[8192]": lines = byteArray(f); break;
                    default: lines = readAll(f);
                }
                long ms = (System.nanoTime() - t0) / 1_000_000;
                long extra = Math.max(0, usedMB() - before);
                System.out.println(mb + "," + m + "," + lines + "," + (m.equals("readAllLines") ? "n/a" : reads) + "," + ms + "," + extra + "   (file bytes=" + bytes + ")");
            }
            Files.delete(Paths.get(f));
        }
    }
}
