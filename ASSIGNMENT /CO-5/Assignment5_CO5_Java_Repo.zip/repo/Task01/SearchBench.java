import java.io.*;
import java.util.*;

/** Scan-per-search vs HashMap-at-startup, n = 1,000 .. 100,000, q = 100 searches. */
public class SearchBench {
    static long usedMB() { Runtime r = Runtime.getRuntime(); return (r.totalMemory() - r.freeMemory()) / (1024 * 1024); }
    public static void main(String[] a) throws Exception {
        int q = 100;
        System.out.println("n,fileKB,q,scanTotalMs,scanPerSearchMs,mapLoadMs,mapQueriesMs,mapTotalMs,mapHeapMB");
        for (int n : new int[]{1000, 10000, 100000}) {
            String f = "bench_" + n + ".txt";
            try (BufferedWriter w = new BufferedWriter(new FileWriter(f))) {
                for (int i = 1; i <= n; i++)
                    w.write("P" + (1000 + i) + "," + (2300000 + i) + ",Student" + i + "," + (i % 40 + 1) + ",Stop" + (i % 97) + ",2026-12-31," + (1000 + i % 900) + ".00\n");
            }
            PassStore s = new PassStore(f);
            Random rnd = new Random(42);
            String[] ids = new String[q];
            for (int i = 0; i < q; i++) ids[i] = "P" + (1000 + 1 + rnd.nextInt(n));   // random existing ids
            for (int i = 0; i < 5; i++) s.find(ids[i]);                                // warm-up

            long t0 = System.nanoTime(); int hit = 0;
            for (String id : ids) if (s.find(id) != null) hit++;
            double scanMs = (System.nanoTime() - t0) / 1e6;

            System.gc(); long before = usedMB();
            t0 = System.nanoTime();
            Map<String, Pass> m = s.loadAll();
            double loadMs = (System.nanoTime() - t0) / 1e6;
            long heap = Math.max(0, usedMB() - before);
            t0 = System.nanoTime(); int hit2 = 0;
            for (String id : ids) if (m.get(id) != null) hit2++;
            double qMs = (System.nanoTime() - t0) / 1e6;
            if (hit != q || hit2 != q) throw new IllegalStateException("lookup mismatch");
            System.out.printf("%d,%d,%d,%.1f,%.2f,%.1f,%.3f,%.1f,%d%n", n, new File(f).length() / 1024, q,
                    scanMs, scanMs / q, loadMs, qMs, loadMs + qMs, heap);
            new File(f).delete();
        }
    }
}
