import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Delimited text-file store for bus passes (design of Task A1). */
public class PassStore {
    private final Path file;
    public int damagedSeen = 0;      // instrumentation: damaged lines skipped in last scan

    public PassStore(String fileName) { this.file = Paths.get(fileName); }

    /** ADD: append one validated line and force it to disk. */
    public void add(Pass p) throws IOException {
        if (p.name.contains(",") || p.stop.contains(","))
            throw new IllegalArgumentException("comma not allowed in name/stop");
        try (FileOutputStream fos = new FileOutputStream(file.toFile(), true);
             Writer w = new OutputStreamWriter(fos, StandardCharsets.UTF_8)) {
            w.write(p.toLine() + "\n");
            w.flush();
            fos.getFD().sync();        // survive power failure after add() returns
        }
    }

    /** TODO 1 (completed): read line by line, skip damaged lines, return the matching record. */
    public Pass find(String passId) throws IOException {
        damagedSeen = 0;
        if (!Files.exists(file)) return null;                     // missing file => no record
        try (BufferedReader br = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            String line;
            while ((line = br.readLine()) != null) {
                Pass p = Pass.parse(line);
                if (p == null) { damagedSeen++; continue; }       // skip damaged line, keep searching
                if (p.passId.equals(passId)) return p;
            }
        }
        return null;
    }

    public List<Pass> listByRoute(int route) throws IOException {
        List<Pass> out = new ArrayList<>();
        damagedSeen = 0;
        if (!Files.exists(file)) return out;
        try (BufferedReader br = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            String line;
            while ((line = br.readLine()) != null) {
                Pass p = Pass.parse(line);
                if (p == null) { damagedSeen++; continue; }
                if (p.route == route) out.add(p);
            }
        }
        return out;
    }

    /** Alternative design: load every valid record into a HashMap once. */
    public Map<String, Pass> loadAll() throws IOException {
        Map<String, Pass> m = new HashMap<>();
        if (!Files.exists(file)) return m;
        try (BufferedReader br = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            String line;
            while ((line = br.readLine()) != null) {
                Pass p = Pass.parse(line);
                if (p != null) m.put(p.passId, p);
            }
        }
        return m;
    }
}
