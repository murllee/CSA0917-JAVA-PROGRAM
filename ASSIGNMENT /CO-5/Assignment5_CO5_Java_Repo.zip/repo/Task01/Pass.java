import java.time.LocalDate;
import java.time.format.DateTimeParseException;

/** One bus-pass record. Text layout: passId,regNo,name,route,stop,validTill,amount */
public class Pass {
    public final String passId, regNo, name, stop;
    public final int route;
    public final LocalDate validTill;
    public final double amount;

    public Pass(String passId, String regNo, String name, int route,
                String stop, LocalDate validTill, double amount) {
        this.passId = passId; this.regNo = regNo; this.name = name;
        this.route = route; this.stop = stop; this.validTill = validTill;
        this.amount = amount;
    }

    /** Returns the record, or null when the line is damaged (never throws). */
    public static Pass parse(String line) {
        if (line == null || line.isBlank()) return null;          // empty line
        String[] f = line.split(",", -1);
        if (f.length != 7) return null;                           // wrong field count
        try {
            String id = f[0].trim();
            if (!id.matches("P\\d+")) return null;                // bad pass id
            if (!f[1].trim().matches("\\d+")) return null;        // bad register number
            if (f[2].isBlank() || f[4].isBlank()) return null;    // missing name / stop
            int route = Integer.parseInt(f[3].trim());
            LocalDate d = LocalDate.parse(f[5].trim());
            double amt = Double.parseDouble(f[6].trim());         // non-numeric amount
            if (amt < 0 || Double.isNaN(amt)) return null;
            return new Pass(id, f[1].trim(), f[2].trim(), route, f[4].trim(), d, amt);
        } catch (NumberFormatException | DateTimeParseException e) {
            return null;
        }
    }

    public String toLine() {
        return passId + "," + regNo + "," + name + "," + route + "," + stop + "," + validTill + ","
                + String.format("%.2f", amount);
    }

    @Override public String toString() { return "Pass[" + toLine() + "]"; }
}
