# CSA09-<RegisterNumber>-Assignment5

Programming in Java (CSA09) - Assignment 5 - CO5: Data Persistence Engineering (Files and Databases)

- Name: ______________________    Register number: ______________________
- Java version: 21 (OpenJDK 21.0.13)
- Database (Tasks 3 and 4): MySQL 8.x with MySQL Connector/J (put the jar on the classpath)

## Compile and run (from inside each task folder)
| Task | Content | Commands |
|------|---------|----------|
| Task01 | B1 File store, TODO 1 PassStore.find(), benchmarks | `javac *.java` ; `java PassStoreDemo` ; `java LineCountBench` ; `java SearchBench` |
| Task02 | B2 Adversarial input | `mysql < users.sql` ; `javac *.java` ; `java DamagedDataTest` ; `java LoginDemo` (add `<jdbcUrl> <user> <password>` to run against MySQL) |
| Task03 | B3 JDBC comparison, TODO 1-3 PassLoader | `mysql < bus_pass.sql` ; `javac PassLoader.java` ; `java -cp .;connector.jar PassLoader <jdbcUrl> <user> <password>` |
| Task04 | B4 Migration + scale check | `javac *.java` ; `java MigrationTool passes_migration.txt --dry-run` ; `java MigrationTool passes_migration.txt <jdbcUrl> <user> <password>` ; `java ScaleCheck` |

(Pass.java and PassStore.java are copied into Task02 / Task04 so that every folder compiles on its own.)

## Results (measured; see *_results.txt / *_output.txt in each folder)
- Task01: find(P1003) returns the record, find(P1002) returns null (damaged line skipped). 50 MB line count: 52,428,836 read calls and 16,433 ms unbuffered vs 6,401 calls and 23 ms with an 8 KB buffer. 100 searches on 100,000 records: scan 3,659 ms vs HashMap 192.6 ms.
- Task02: unsafe login SQL text shows the injection; 6 kinds of damaged lines rejected without a crash.
- Task03: fill in timings from your MySQL run.
- Task04: dry run - 20 lines, 17 valid, 3 rejected. 800,000 records: HashMap needs about 256 MB; worst-case scan about 870 ms.

## Screenshots
Put execution screenshots in `Task0N/screenshots/` and name each after the test it shows.

## Suggested commit order (at least one commit per task)
git add Task01 && git commit -m "Task01: bus-pass file store and I/O benchmarks"
git add Task02 && git commit -m "Task02: adversarial login and damaged-data tests"
git add Task03 && git commit -m "Task03: JDBC loader (Statement, PreparedStatement, batch)"
git add Task04 && git commit -m "Task04: migration tool and scale check"
git add README.md && git commit -m "README"
