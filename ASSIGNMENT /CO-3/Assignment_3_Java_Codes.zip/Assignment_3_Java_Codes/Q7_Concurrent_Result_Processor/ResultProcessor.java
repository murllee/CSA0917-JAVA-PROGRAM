import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

public class ResultProcessor {
    static void createFiles() throws IOException {
        Files.createDirectories(Paths.get("results"));
        for (int i = 0; i < 10000; i++) {
            Path file = Paths.get("results/student" + i + ".txt");
            if (i == 9999) continue; // Leave one file missing
            if (i == 5000) {
                Files.writeString(file, "INVALID DATA");
            } else {
                Files.writeString(file, "Student" + i + ",85");
            }
        }
    }

    static void processFiles(int threadCount)
            throws InterruptedException, ExecutionException {
        ExecutorService pool = Executors.newFixedThreadPool(threadCount);
        ConcurrentLinkedQueue<String> success = new ConcurrentLinkedQueue<>();
        ConcurrentLinkedQueue<String> failure = new ConcurrentLinkedQueue<>();
        List<Future<Void>> futures = new ArrayList<>();
        long start = System.nanoTime();

        try {
            for (int i = 0; i < 10000; i++) {
                final int id = i;
                Callable<Void> task = () -> {
                    String fileName = "results/student" + id + ".txt";
                    try {
                        String data = Files.readString(Paths.get(fileName));
                        String[] parts = data.trim().split(",");
                        if (parts.length != 2)
                            throw new IllegalArgumentException("Invalid file format");
                        int marks = Integer.parseInt(parts[1]);
                        if (marks < 0 || marks > 100)
                            throw new IllegalArgumentException("Invalid marks");
                        success.add(fileName);
                    } catch (IOException | IllegalArgumentException e) {
                        // NumberFormatException is a subclass of IllegalArgumentException.
                        failure.add(fileName + ": " + e.getMessage());
                    }
                    return null;
                };
                futures.add(pool.submit(task));
            }
            for (Future<Void> f : futures) f.get();
        } finally {
            pool.shutdown();
        }

        long end = System.nanoTime();
        System.out.println("\\nThreads: " + threadCount);
        System.out.println("Successful: " + success.size());
        System.out.println("Failed: " + failure.size());
        System.out.println("Execution time: " + (end - start) + " ns");
    }

    public static void main(String[] args) throws Exception {
        createFiles();
        int[] threadCounts = {1, 2, 4, 8};
        for (int count : threadCounts) processFiles(count);
    }
}
