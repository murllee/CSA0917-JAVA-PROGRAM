import java.util.*;

/** Q3 - hashCode/equals contract: tests, complete-the-code program, and alternative structures. */
public class Q3HashContract {

    // (a) junior developer's class: equals() only
    static class StudentBad {
        String regNo; String name;
        StudentBad(String r, String n) { regNo = r; name = n; }
        @Override public boolean equals(Object o) {
            if (!(o instanceof StudentBad)) return false;
            return regNo.equals(((StudentBad) o).regNo);
        }
    }
    // (b) hashCode uses a DIFFERENT field set from equals (name added) -> still violates contract
    static class StudentInconsistent extends StudentBad {
        StudentInconsistent(String r, String n) { super(r, n); }
        @Override public int hashCode() { return Objects.hash(regNo, name); }
    }
    // (c) correct: hashCode on exactly the field used by equals; field is final (immutable)
    static final class StudentGood {
        private final String regNo; private final String name;
        StudentGood(String r, String n) { regNo = r; name = n; }
        @Override public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof StudentGood s)) return false;
            return regNo.equals(s.regNo);
        }
        @Override public int hashCode() { return regNo.hashCode(); }   // TODO 1 solution
        @Override public String toString() { return regNo + "/" + name; }
    }
    // (d) mutable key used in hashCode
    static class StudentMutable {
        String regNo; String name;
        StudentMutable(String r, String n) { regNo = r; name = n; }
        @Override public boolean equals(Object o) { return o instanceof StudentMutable s && regNo.equals(s.regNo); }
        @Override public int hashCode() { return regNo.hashCode(); }
    }
    // (e) legal but terrible: constant hashCode
    static class StudentConstHash {
        final String regNo;
        StudentConstHash(String r) { regNo = r; }
        @Override public boolean equals(Object o) { return o instanceof StudentConstHash s && regNo.equals(s.regNo); }
        @Override public int hashCode() { return 42; }
    }

    static void tests() {
        System.out.println("=== TEST 1: faulty class (equals only) ===");
        System.out.println("Prediction: 4 (default identity hashCode -> different buckets, equals never consulted)");
        Set<StudentBad> s1 = new HashSet<>();
        s1.add(new StudentBad("21CS001", "Asha")); s1.add(new StudentBad("21CS001", "Asha"));
        s1.add(new StudentBad("21CS002", "Ravi")); s1.add(new StudentBad("21CS002", "Ravi"));
        System.out.println("Observed set size: " + s1.size());
        StudentBad a = new StudentBad("21CS001", "Asha"), b = new StudentBad("21CS001", "Asha");
        System.out.println("a.equals(b) = " + a.equals(b) + ", a.hashCode()==b.hashCode() : " + (a.hashCode() == b.hashCode()));
        System.out.println("contains(new equal object) = " + s1.contains(new StudentBad("21CS001", "Asha")));

        System.out.println("\n=== TEST 2: hashCode uses a different field set (regNo+name) than equals (regNo) ===");
        System.out.println("Prediction: 3 (the two 21CS001 scans differ in name, so their hashes differ; the two 21CS002 scans are identical and merge)");
        Set<StudentInconsistent> s2 = new HashSet<>();
        s2.add(new StudentInconsistent("21CS001", "Asha")); s2.add(new StudentInconsistent("21CS001", "ASHA K"));
        s2.add(new StudentInconsistent("21CS002", "Ravi")); s2.add(new StudentInconsistent("21CS002", "Ravi"));
        System.out.println("Observed set size: " + s2.size());

        System.out.println("\n=== TEST 3: corrected class (hashCode on regNo only) ===");
        System.out.println("Prediction: 2");
        Set<StudentGood> s3 = new HashSet<>();
        s3.add(new StudentGood("21CS001", "Asha")); s3.add(new StudentGood("21CS001", "ASHA K"));
        s3.add(new StudentGood("21CS002", "Ravi")); s3.add(new StudentGood("21CS002", "Ravi"));
        System.out.println("Observed set size: " + s3.size());
        System.out.println("contains(new equal object) = " + s3.contains(new StudentGood("21CS002", "x")));

        System.out.println("\n=== TEST 4: field used in hashCode changed AFTER adding ===");
        System.out.println("Prediction: contains() false and remove() false although the element is still inside");
        Set<StudentMutable> s4 = new HashSet<>();
        StudentMutable m = new StudentMutable("21CS010", "Meena");
        s4.add(m);
        m.regNo = "21CS999";
        System.out.println("size = " + s4.size() + ", contains(m) = " + s4.contains(m) + ", remove(m) = " + s4.remove(m) + ", size after remove = " + s4.size());
        s4.add(m);
        System.out.println("add(m) again -> size = " + s4.size() + " (same object stored twice)");
    }

    /** Complete-the-code program (TODO 1 = hashCode in StudentGood). */
    static void completeTheCode() {
        System.out.println("\n=== COMPLETE-THE-CODE program ===");
        Set<StudentGood> set = new HashSet<>();
        set.add(new StudentGood("21CS001", "Asha"));
        set.add(new StudentGood("21CS001", "Asha"));
        set.add(new StudentGood("21CS002", "Ravi"));
        set.add(new StudentGood("21CS002", "Ravi"));
        System.out.println("Unique students: " + set.size());
        Set<StudentBad> bad = new HashSet<>();
        bad.add(new StudentBad("21CS001", "Asha")); bad.add(new StudentBad("21CS001", "Asha"));
        bad.add(new StudentBad("21CS002", "Ravi")); bad.add(new StudentBad("21CS002", "Ravi"));
        System.out.println("Unique students (without TODO 1 / no hashCode): " + bad.size());
    }

    static volatile long sink;
    static void performance() {
        System.out.println("\n=== Time per scan: HashSet vs TreeSet(Comparator) vs HashMap<String,Student> vs constant hashCode ===");
        System.out.printf("%10s %12s %12s %12s %16s%n", "scans", "HashSet(ms)", "TreeSet(ms)", "HashMap(ms)", "ConstHash(ms)");
        int[] ns = {2_000, 20_000, 200_000};
        for (int pass = 0; pass < 2; pass++) {
            for (int n : ns) {
                int uniq = n / 2;
                String[] regs = new String[n];
                Random r = new Random(1);
                for (int i = 0; i < n; i++) regs[i] = "21CS" + String.format("%06d", r.nextInt(uniq));
                long t0 = System.nanoTime();
                Set<StudentGood> hs = new HashSet<>(); for (String g : regs) hs.add(new StudentGood(g, "n"));
                double h = (System.nanoTime() - t0) / 1e6;
                t0 = System.nanoTime();
                Set<StudentGood> ts = new TreeSet<>(Comparator.comparing(s -> s.regNo)); for (String g : regs) ts.add(new StudentGood(g, "n"));
                double t = (System.nanoTime() - t0) / 1e6;
                t0 = System.nanoTime();
                Map<String, StudentGood> hm = new HashMap<>(); for (String g : regs) hm.putIfAbsent(g, new StudentGood(g, "n"));
                double m = (System.nanoTime() - t0) / 1e6;
                double c = Double.NaN;
                if (n <= 20_000) {
                    t0 = System.nanoTime();
                    Set<StudentConstHash> cs = new HashSet<>(); for (String g : regs) cs.add(new StudentConstHash(g));
                    c = (System.nanoTime() - t0) / 1e6; sink += cs.size();
                }
                sink += hs.size() + ts.size() + hm.size();
                if (pass == 1)
                    System.out.printf("%10d %12.2f %12.2f %12.2f %16s   (unique: %d/%d/%d)%n", n, h, t, m,
                            Double.isNaN(c) ? "skipped" : String.format("%.2f", c), hs.size(), ts.size(), hm.size());
            }
        }
    }

    public static void main(String[] args) {
        System.out.println("Java " + System.getProperty("java.version"));
        tests();
        completeTheCode();
        performance();
    }
}
