import java.util.*;

/** Q6 - growth investigation, starvation + aging, and alternative designs for triage. */
public class Q6Experiments {
    record P(int sev, long arrival, long key) {}
    static volatile long sink;
    static final Comparator<P> STRICT = Comparator.comparingInt(P::sev).thenComparingLong(P::arrival);
    static final Comparator<P> AGING = Comparator.comparingLong(P::key).thenComparingLong(P::arrival);

    static void growth() {
        System.out.println("=== Growth: PriorityQueue add / poll cost per operation (ns), average of 3 runs ===");
        System.out.printf("%12s %12s %12s %12s%n", "queue size n", "add ns/op", "poll ns/op", "log2(n)");
        for (int pass = 0; pass < 2; pass++)
            for (int n : new int[]{1_000, 10_000, 100_000, 1_000_000}) {
                double add = 0, poll = 0;
                for (int r = 0; r < 3; r++) {
                    Random rnd = new Random(r);
                    P[] ps = new P[n];
                    for (int i = 0; i < n; i++) ps[i] = new P(1 + rnd.nextInt(5), i, 0);
                    PriorityQueue<P> q = new PriorityQueue<>(STRICT);
                    long t0 = System.nanoTime(); for (P p : ps) q.add(p); add += (System.nanoTime() - t0) / (double) n;
                    t0 = System.nanoTime(); long s = 0; while (!q.isEmpty()) s += q.poll().sev(); poll += (System.nanoTime() - t0) / (double) n; sink += s;
                }
                if (pass == 1) System.out.printf("%12d %12.1f %12.1f %12.1f%n", n, add / 3, poll / 3, Math.log(n) / Math.log(2));
            }
    }

    static void starvation() {
        System.out.println("\n=== Starvation: 1 severity-5 patient arrives at tick 0; every tick 2 patients of severity 1-2 arrive, 1 patient is served ===");
        int ticks = 20_000; long W = 500;
        for (String mode : new String[]{"strict priority", "aging (key = arrival + 500*severity)"}) {
            PriorityQueue<P> q = new PriorityQueue<>(mode.startsWith("strict") ? STRICT : AGING);
            boolean aging = !mode.startsWith("strict");
            Random r = new Random(1);
            q.add(new P(5, 0, aging ? 5 * W : 0));
            long servedAt = -1; long waitSumSev1 = 0, cntSev1 = 0, maxWaitSev1 = 0; long arrivalCounter = 1;
            Map<Long, Long> arrTick = new HashMap<>();
            for (long t = 0; t < ticks; t++) {
                for (int k = 0; k < 2; k++) {
                    int sev = 1 + r.nextInt(2);
                    q.add(new P(sev, arrivalCounter, aging ? t + W * sev : 0)); arrTick.put(arrivalCounter, t); arrivalCounter++;
                }
                P p = q.poll();
                if (p.sev() == 5 && servedAt < 0) servedAt = t;
                if (p.sev() == 1) { long w = t - arrTick.getOrDefault(p.arrival(), 0L); waitSumSev1 += w; cntSev1++; maxWaitSev1 = Math.max(maxWaitSev1, w); }
            }
            System.out.printf("%-38s severity-5 patient served at tick: %s | served sev-1 patients: %d, mean wait %.0f ticks, max wait %d ticks | queue left: %d%n",
                    mode, servedAt < 0 ? "NEVER (within " + ticks + ")" : String.valueOf(servedAt), cntSev1, cntSev1 == 0 ? 0 : waitSumSev1 / (double) cntSev1, maxWaitSev1, q.size());
        }
    }

    // ---- alternative designs -------------------------------------------------
    static void alternatives() {
        System.out.println("\n=== Alternative designs: total time to admit n patients then serve all n (ms) ===");
        System.out.printf("%8s %18s %24s %26s%n", "n", "PriorityQueue", "sorted LinkedList", "5 FIFO queues (ArrayDeque)");
        for (int pass = 0; pass < 2; pass++)
            for (int n : new int[]{2_000, 10_000, 40_000}) {
                Random rnd = new Random(2); P[] ps = new P[n];
                for (int i = 0; i < n; i++) ps[i] = new P(1 + rnd.nextInt(5), i, 0);
                long t0 = System.nanoTime();
                PriorityQueue<P> q = new PriorityQueue<>(STRICT); for (P p : ps) q.add(p); while (!q.isEmpty()) sink += q.poll().sev();
                double pq = (System.nanoTime() - t0) / 1e6;

                t0 = System.nanoTime();
                LinkedList<P> l = new LinkedList<>();
                for (P p : ps) { ListIterator<P> it = l.listIterator(); while (it.hasNext()) { if (STRICT.compare(it.next(), p) > 0) { it.previous(); break; } } it.add(p); }
                while (!l.isEmpty()) sink += l.removeFirst().sev();
                double ll = (System.nanoTime() - t0) / 1e6;

                t0 = System.nanoTime();
                @SuppressWarnings("unchecked") ArrayDeque<P>[] qs = new ArrayDeque[6]; for (int i = 1; i <= 5; i++) qs[i] = new ArrayDeque<>();
                for (P p : ps) qs[p.sev()].addLast(p);
                for (int served = 0; served < n; served++) for (int s = 1; s <= 5; s++) if (!qs[s].isEmpty()) { sink += qs[s].pollFirst().sev(); break; }
                double fifo = (System.nanoTime() - t0) / 1e6;
                if (pass == 1) System.out.printf("%8d %18.2f %24.2f %26.2f%n", n, pq, ll, fifo);
            }
    }

    public static void main(String[] args) {
        System.out.println("Java " + System.getProperty("java.version"));
        growth(); starvation(); alternatives();
        long n = 5000; Random rnd = new Random(1);
        PriorityQueue<P> q = new PriorityQueue<>(STRICT);
        long t0 = System.nanoTime();
        for (int i = 0; i < n; i++) q.add(new P(1 + rnd.nextInt(5), i, 0));
        while (!q.isEmpty()) sink += q.poll().sev();
        System.out.printf("%nOne full day for a city hospital (5,000 patients admitted then all served): %.3f ms%n", (System.nanoTime() - t0) / 1e6);
    }
}
