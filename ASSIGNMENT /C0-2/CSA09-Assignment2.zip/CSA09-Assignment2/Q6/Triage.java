import java.util.Comparator;
import java.util.PriorityQueue;

public class Triage {
    private long counter = 0;

    // TODO 1 (completed): lowest severity number first; for equal severity, earliest arrival first
    private final PriorityQueue<Patient> queue = new PriorityQueue<>(
            Comparator.comparingInt((Patient p) -> p.severity).thenComparingLong(p -> p.arrival));

    void admit(String name, int severity) {
        queue.add(new Patient(name, severity, counter++));
    }

    Patient next() { return queue.poll(); }

    public static void main(String[] args) {
        Triage t = new Triage();
        t.admit("Anu", 3);  t.admit("Bala", 1); t.admit("Chitra", 2); t.admit("Dev", 1);
        t.admit("Esha", 5); t.admit("Farid", 2); t.admit("Gita", 3);  t.admit("Hari", 1);

        System.out.println("Printing the PriorityQueue directly (heap array order, NOT treatment order):");
        System.out.println(t.queue);
        System.out.println("\nTreatment order (poll until empty):");
        Patient p;
        int i = 1;
        while ((p = t.next()) != null) System.out.println(i++ + ". " + p + "  arrived #" + p.arrival);
        System.out.println("\nHand-worked expected: Bala(S1), Dev(S1), Hari(S1), Chitra(S2), Farid(S2), Anu(S3), Gita(S3), Esha(S5)");
    }
}

class Patient {
    final String name; final int severity; final long arrival;
    Patient(String name, int severity, long arrival) {
        this.name = name; this.severity = severity; this.arrival = arrival;
    }
    @Override public String toString() { return name + "(S" + severity + ")"; }
}
