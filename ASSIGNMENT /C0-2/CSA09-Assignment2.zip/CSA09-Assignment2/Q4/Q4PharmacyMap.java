import java.util.*;

/** Q4 - Pharmacy inventory: HashMap / LinkedHashMap / TreeMap / Hashtable / sorted array + binarySearch. */
public class Q4PharmacyMap {
    record Medicine(String code, String name, int stock) {}
    static volatile long sink;

    static String[] codes(int n) {
        String[] c = new String[n];
        for (int i = 0; i < n; i++) c[i] = String.format("MED%07d", i * 7 + 13);
        List<String> l = new ArrayList<>(Arrays.asList(c));
        Collections.shuffle(l, new Random(7));          // insertion order != code order
        return l.toArray(new String[0]);
    }

    static double lookups(java.util.function.Function<String, Medicine> f, String[] keys, int count) {
        Random r = new Random(3);
        long t0 = System.nanoTime(); long s = 0;
        for (int i = 0; i < count; i++) s += f.apply(keys[r.nextInt(keys.length)]).stock();
        sink += s;
        return (System.nanoTime() - t0) / 1e6;
    }

    public static void main(String[] args) {
        System.out.println("Java " + System.getProperty("java.version"));
        int[] sizes = {1_000, 50_000, 500_000};
        for (int pass = 0; pass < 2; pass++) {
            for (int n : sizes) {
                String[] keys = codes(n);
                Medicine[] meds = new Medicine[n];
                for (int i = 0; i < n; i++) meds[i] = new Medicine(keys[i], "Drug" + i, i % 500);

                HashMap<String, Medicine> hm = new HashMap<>();
                LinkedHashMap<String, Medicine> lhm = new LinkedHashMap<>();
                TreeMap<String, Medicine> tm = new TreeMap<>();
                Hashtable<String, Medicine> ht = new Hashtable<>();
                long t0 = System.nanoTime(); for (Medicine m : meds) hm.put(m.code(), m);   double bHm = (System.nanoTime() - t0) / 1e6;
                t0 = System.nanoTime(); for (Medicine m : meds) lhm.put(m.code(), m);       double bL = (System.nanoTime() - t0) / 1e6;
                t0 = System.nanoTime(); for (Medicine m : meds) tm.put(m.code(), m);        double bT = (System.nanoTime() - t0) / 1e6;
                t0 = System.nanoTime(); for (Medicine m : meds) ht.put(m.code(), m);        double bH = (System.nanoTime() - t0) / 1e6;
                t0 = System.nanoTime();
                Medicine[] sorted = meds.clone(); Arrays.sort(sorted, Comparator.comparing(Medicine::code));
                double bA = (System.nanoTime() - t0) / 1e6;
                String[] sortedKeys = new String[n]; for (int i = 0; i < n; i++) sortedKeys[i] = sorted[i].code();

                double lHm = lookups(hm::get, keys, 100_000), lL = lookups(lhm::get, keys, 100_000),
                       lT = lookups(tm::get, keys, 100_000), lH = lookups(ht::get, keys, 100_000),
                       lA = lookups(k -> sorted[Arrays.binarySearch(sortedKeys, k)], keys, 100_000);

                // reports
                t0 = System.nanoTime(); List<String> codeOrderHm = new ArrayList<>(hm.keySet()); Collections.sort(codeOrderHm);
                double rHmCode = (System.nanoTime() - t0) / 1e6;
                t0 = System.nanoTime(); List<String> codeOrderTm = new ArrayList<>(tm.keySet()); double rTmCode = (System.nanoTime() - t0) / 1e6;
                t0 = System.nanoTime(); List<String> addOrder = new ArrayList<>(lhm.keySet()); double rLhmAdd = (System.nanoTime() - t0) / 1e6;
                t0 = System.nanoTime(); List<String> arrCode = new ArrayList<>(n); for (Medicine m : sorted) arrCode.add(m.code()); double rArr = (System.nanoTime() - t0) / 1e6;

                boolean okCode = codeOrderHm.equals(codeOrderTm) && codeOrderTm.equals(arrCode);
                boolean okAdd = addOrder.equals(Arrays.asList(keys));
                boolean hmAddOrder = new ArrayList<>(hm.keySet()).equals(Arrays.asList(keys));
                boolean hmCodeOrder = new ArrayList<>(hm.keySet()).equals(codeOrderTm);

                // sorted-array insertion: 1,000 new medicines
                Medicine[] arr = Arrays.copyOf(sorted, n + 1000); int size = n;
                t0 = System.nanoTime();
                for (int i = 0; i < 1000; i++) {
                    String code = String.format("MED%07d", 5 + i * 3);
                    int pos = Arrays.binarySearch(arr, 0, size, new Medicine(code, "x", 0), Comparator.comparing(Medicine::code));
                    if (pos < 0) pos = -pos - 1;
                    System.arraycopy(arr, pos, arr, pos + 1, size - pos); arr[pos] = new Medicine(code, "x", 0); size++;
                }
                double insArr = (System.nanoTime() - t0) / 1e6;
                t0 = System.nanoTime();
                for (int i = 0; i < 1000; i++) { tm.put(String.format("MED%07d", 5 + i * 3), meds[0]); }
                double insTm = (System.nanoTime() - t0) / 1e6;
                t0 = System.nanoTime();
                for (int i = 0; i < 1000; i++) { hm.put(String.format("MED%07d", 5 + i * 3), meds[0]); }
                double insHm = (System.nanoTime() - t0) / 1e6;

                if (pass == 1) {
                    System.out.printf("%n=== n = %,d medicines ===%n", n);
                    System.out.printf("%-26s %10s %10s %10s %10s %10s%n", "", "HashMap", "LinkedHM", "TreeMap", "Hashtable", "SortedArr");
                    System.out.printf("%-26s %10.1f %10.1f %10.1f %10.1f %10.1f%n", "build (ms)", bHm, bL, bT, bH, bA);
                    System.out.printf("%-26s %10.1f %10.1f %10.1f %10.1f %10.1f%n", "100,000 lookups (ms)", lHm, lL, lT, lH, lA);
                    System.out.printf("%-26s %10.4f %10.4f %10.4f %10.4f %10.4f%n", "per lookup (us)", lHm / 100, lL / 100, lT / 100, lH / 100, lA / 100);
                    System.out.printf("%-26s %10.2f %10s %10.2f %10s %10.2f%n", "code-order report (ms)", rHmCode, "n/a", rTmCode, "n/a", rArr);
                    System.out.printf("%-26s %10s %10.2f %10s %10s %10s%n", "insertion-order report(ms)", "n/a", rLhmAdd, "n/a", "n/a", "n/a");
                    System.out.printf("%-26s %10.2f %10s %10.2f %10s %10.2f%n", "1,000 inserts (ms)", insHm, "-", insTm, "-", insArr);
                    System.out.println("Order check: code-order reports equal = " + okCode + " | LinkedHashMap = insertion order: " + okAdd
                            + " | plain HashMap iteration is insertion order: " + hmAddOrder + ", code order: " + hmCodeOrder);
                }
            }
        }
    }
}
