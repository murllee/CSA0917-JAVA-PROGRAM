import java.lang.management.ManagementFactory;
import java.util.*;
import java.util.function.Supplier;

/** Q2 - Music playlist editor: ArrayList vs LinkedList (and ArrayDeque for the "Up Next" queue). */
public class Q2Playlist {
    record Song(int id, String title) {}

    static final com.sun.management.ThreadMXBean MX =
            (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
    @SuppressWarnings("deprecation")
    static long alloc() { return MX.getThreadAllocatedBytes(Thread.currentThread().getId()); }
    static volatile long sink;

    static final int M = 1000;          // operations per measured experiment
    static final int REPEATS = 3;       // averaged runs
    static Song[] pool;

    static List<Song> build(Supplier<List<Song>> s, int n) {
        List<Song> l = s.get();
        for (int i = 0; i < n; i++) l.add(pool[i]);
        return l;
    }

    /** microseconds per operation, averaged over REPEATS runs. */
    static double[] run(Supplier<List<Song>> sup, int n) {
        double addEnd = 0, insF = 0, remF = 0, insM = 0, remM = 0, get = 0, iter = 0;
        Random rnd = new Random(42);
        for (int r = 0; r < REPEATS; r++) {
            long t0 = System.nanoTime();
            List<Song> l = build(sup, n);
            addEnd += (System.nanoTime() - t0) / 1e3 / n;

            Song x = pool[0];
            t0 = System.nanoTime(); for (int i = 0; i < M; i++) l.add(0, x);               insF += (System.nanoTime() - t0) / 1e3 / M;
            t0 = System.nanoTime(); for (int i = 0; i < M; i++) l.remove(0);              remF += (System.nanoTime() - t0) / 1e3 / M;
            t0 = System.nanoTime(); for (int i = 0; i < M; i++) l.add(l.size() / 2, x);    insM += (System.nanoTime() - t0) / 1e3 / M;
            t0 = System.nanoTime(); for (int i = 0; i < M; i++) l.remove(l.size() / 2);    remM += (System.nanoTime() - t0) / 1e3 / M;

            int[] ks = new int[M]; for (int i = 0; i < M; i++) ks[i] = rnd.nextInt(n);
            t0 = System.nanoTime(); long s = 0; for (int i = 0; i < M; i++) s += l.get(ks[i]).id(); get += (System.nanoTime() - t0) / 1e3 / M; sink += s;

            t0 = System.nanoTime(); for (int p = 0; p < 5; p++) for (Song a : l) sink += a.id(); iter += (System.nanoTime() - t0) / 1e6 / 5;
        }
        return new double[]{addEnd / REPEATS, insF / REPEATS, remF / REPEATS, insM / REPEATS, remM / REPEATS, get / REPEATS, iter / REPEATS};
    }

    static double bytesPerElement(Supplier<List<Song>> sup, int n) {
        long a0 = alloc(); List<Song> l = build(sup, n); long a1 = alloc(); sink += l.size();
        return (a1 - a0) / (double) n;
    }

    static void upNext(int start, int ops) {
        System.out.printf("%n=== 'Up Next' queue: start with %,d songs, then %,d operations (addFirst / addLast / removeFirst in rotation) ===%n", start, ops);
        System.out.printf("%-12s %14s%n", "Structure", "total (ms)");
        for (int rep = 0; rep < 2; rep++) {            // first pass = warm-up
            double a = timeQueue(new ArrayList<Song>(), start, ops);
            double b = timeQueue(new LinkedList<Song>(), start, ops);
            double c = timeDeque(new ArrayDeque<Song>(), start, ops);
            if (rep == 1) {
                System.out.printf("%-12s %14.2f%n", "ArrayList", a);
                System.out.printf("%-12s %14.2f%n", "LinkedList", b);
                System.out.printf("%-12s %14.2f%n", "ArrayDeque", c);
            }
        }
    }
    static double timeQueue(List<Song> l, int start, int ops) {
        for (int i = 0; i < start; i++) l.add(pool[i]);
        long t0 = System.nanoTime();
        for (int i = 0; i < ops; i++) {
            switch (i % 3) { case 0 -> l.add(0, pool[i % 1000]); case 1 -> l.add(pool[i % 1000]); default -> l.remove(0); }
        }
        return (System.nanoTime() - t0) / 1e6;
    }
    static double timeDeque(ArrayDeque<Song> d, int start, int ops) {
        for (int i = 0; i < start; i++) d.addLast(pool[i]);
        long t0 = System.nanoTime();
        for (int i = 0; i < ops; i++) {
            switch (i % 3) { case 0 -> d.addFirst(pool[i % 1000]); case 1 -> d.addLast(pool[i % 1000]); default -> d.pollFirst(); }
        }
        return (System.nanoTime() - t0) / 1e6;
    }

    public static void main(String[] args) {
        System.out.println("Java " + System.getProperty("java.version"));
        int[] sizes = {10_000, 100_000, 500_000};
        pool = new Song[sizes[sizes.length - 1]];
        for (int i = 0; i < pool.length; i++) pool[i] = new Song(i, "Song" + i);

        run(ArrayList::new, 10_000); run(LinkedList::new, 10_000);      // JIT warm-up (discarded)

        String[] names = {"add at end (us/op)", "insert front (us/op)", "remove front (us/op)",
                "insert middle (us/op)", "remove middle (us/op)", "get(k) random (us/op)", "iterate all (ms/pass)"};
        for (int n : sizes) {
            double[] a = run(ArrayList::new, n), l = run(LinkedList::new, n);
            System.out.printf("%n=== Playlist size n = %,d  (M = %d operations per test, average of %d runs) ===%n", n, M, REPEATS);
            System.out.printf("%-24s %14s %14s %12s%n", "Operation", "ArrayList", "LinkedList", "LL/AL");
            for (int i = 0; i < names.length; i++)
                System.out.printf("%-24s %14.4f %14.4f %12.2f%n", names[i], a[i], l[i], l[i] / a[i]);
            System.out.printf("%-24s %14.1f %14.1f%n", "bytes per element (list only)",
                    bytesPerElement(ArrayList::new, n), bytesPerElement(LinkedList::new, n));
        }
        upNext(100_000, 60_000);
    }
}
