import java.util.*;

/** Q5 - Generic ranking component: Leaderboard<T>, Comparator chain, broken comparators, alternatives. */
public class Q5Leaderboard {

    static class Team {
        final String name; final int points; final int goalDiff;
        Team(String name, int points, int goalDiff) { this.name = name; this.points = points; this.goalDiff = goalDiff; }
        @Override public String toString() { return name + "(" + points + "," + goalDiff + ")"; }
        String name() { return name; } int points() { return points; } int goalDiff() { return goalDiff; }
    }
    static class CollegeTeam extends Team {          // subtype, to show Comparator<? super T> and List<? extends T>
        CollegeTeam(String n, int p, int g) { super(n, p, g); }
    }

    /** Alternative design: natural ordering baked into the class. */
    static class RankedTeam extends Team implements Comparable<RankedTeam> {
        RankedTeam(String n, int p, int g) { super(n, p, g); }
        @Override public int compareTo(RankedTeam o) {
            int c = Integer.compare(o.points, points);
            if (c != 0) return c;
            c = Integer.compare(o.goalDiff, goalDiff);
            return c != 0 ? c : name.compareTo(o.name);
        }
    }

    static class Leaderboard<T> {
        private final List<T> items = new ArrayList<>();
        private final Comparator<? super T> order;

        Leaderboard(Comparator<? super T> order) { this.order = order; }

        /** Bounded factory: works for any T that is naturally comparable. */
        static <T extends Comparable<? super T>> Leaderboard<T> natural() { return new Leaderboard<>(Comparator.naturalOrder()); }

        void add(T item) { items.add(item); }
        /** Producer wildcard: a list of subtypes can be added. */
        void addAll(Collection<? extends T> more) { items.addAll(more); }

        List<T> ranking() {
            // TODO 1 solution: new sorted copy, original untouched
            List<T> copy = new ArrayList<>(items);
            copy.sort(order);
            return copy;
        }
        List<T> top(int k) { List<T> r = ranking(); return r.subList(0, Math.min(k, r.size())); }
        int size() { return items.size(); }
    }

    static final Comparator<Team> CORRECT = Comparator.comparingInt(Team::points).reversed()
            .thenComparing(Comparator.comparingInt(Team::goalDiff).reversed())
            .thenComparing(Team::name);
    static final Comparator<Team> FAULTY_SUBTRACT = (a, b) -> b.points - a.points;            // overflow-prone, no tie-breaks
    static final Comparator<Team> FAULTY_NO_TIEBREAK = (a, b) -> Integer.compare(b.points, a.points); // ignores goalDiff & name

    static void show(String label, List<Team> l) { System.out.println(label + ": " + l); }

    public static void main(String[] args) {
        System.out.println("Java " + System.getProperty("java.version"));
        List<Team> data1 = List.of(
                new Team("Eagles", 9, 5), new Team("Lions", 9, 5), new Team("Tigers", 9, 2),
                new Team("Sharks", 7, 1), new Team("Wolves", 7, 1), new Team("Bears", 7, -3),
                new Team("Hawks", 4, 0), new Team("Foxes", 4, 0), new Team("Owls", 0, -9));
        System.out.println("=== DATA SET 1: ties at every level ===");
        Leaderboard<Team> lb = new Leaderboard<>(CORRECT);
        lb.addAll(data1);
        show("Insertion order       ", data1);
        show("Correct comparator    ", lb.ranking());
        show("Original items intact ", new ArrayList<>(data1));
        show("Faulty: no tie-breaker", sorted(data1, FAULTY_NO_TIEBREAK));
        System.out.println("Hand-worked expected   : [Eagles(9,5), Lions(9,5), Tigers(9,2), Sharks(7,1), Wolves(7,1), Bears(7,-3), Foxes(4,0), Hawks(4,0), Owls(0,-9)]");

        System.out.println("\n=== DATA SET 2: designed to break subtraction comparator (extreme points) ===");
        List<Team> data2 = new ArrayList<>(List.of(
                new Team("Big", Integer.MAX_VALUE, 0), new Team("Neg", -Integer.MAX_VALUE, 0),
                new Team("Zero", 0, 0), new Team("Mid", 5, 0)));
        show("Correct comparator    ", sorted(data2, CORRECT));
        show("Faulty (subtraction)  ", sorted(data2, FAULTY_SUBTRACT));
        System.out.println("Check: Big - Neg = " + (Integer.MAX_VALUE - (-Integer.MAX_VALUE)) + " (overflowed to negative, so Big appears to rank BELOW Neg)");

        System.out.println("\n=== DATA SET 3: 200 random extreme teams -> TimSort contract check ===");
        Random r = new Random(5);
        List<Team> big = new ArrayList<>();
        int[] extremes = {Integer.MAX_VALUE, -Integer.MAX_VALUE, 1_500_000_000, -1_500_000_000, 0, 7};
        for (int i = 0; i < 200; i++) big.add(new Team("T" + i, extremes[r.nextInt(extremes.length)], r.nextInt(5)));
        try { sorted(big, FAULTY_SUBTRACT); System.out.println("Faulty subtraction comparator: no exception (result still unreliable)"); }
        catch (IllegalArgumentException e) { System.out.println("Faulty subtraction comparator threw: " + e.getMessage()); }
        List<Team> ok = sorted(big, CORRECT);
        boolean sortedOk = true;
        for (int i = 1; i < ok.size(); i++) if (CORRECT.compare(ok.get(i - 1), ok.get(i)) > 0) sortedOk = false;
        System.out.println("Correct comparator result valid & transitive: " + sortedOk);

        System.out.println("\n=== Wildcards: Comparator<? super T> and Collection<? extends T> ===");
        Leaderboard<CollegeTeam> college = new Leaderboard<>(CORRECT);   // Comparator<Team> reused for CollegeTeam
        college.addAll(List.of(new CollegeTeam("MIT-A", 6, 2), new CollegeTeam("IIT-B", 6, 4)));
        System.out.println("Leaderboard<CollegeTeam> with Comparator<Team>: " + college.ranking());
        Leaderboard<RankedTeam> nat = Leaderboard.natural();
        nat.add(new RankedTeam("A", 3, 1)); nat.add(new RankedTeam("B", 3, 2)); nat.add(new RankedTeam("C", 9, 0));
        System.out.println("Comparable-based Leaderboard.natural(): " + nat.ranking());

        System.out.println("\n=== Alternatives: ONE comparator chain vs THREE stable sorts (200,000 teams) ===");
        Random rr = new Random(9);
        List<Team> many = new ArrayList<>();
        for (int i = 0; i < 200_000; i++) many.add(new Team("N" + rr.nextInt(50_000), rr.nextInt(30), rr.nextInt(15)));
        for (int pass = 0; pass < 3; pass++) {
            List<Team> a = new ArrayList<>(many);
            long t0 = System.nanoTime(); a.sort(CORRECT); double chain = (System.nanoTime() - t0) / 1e6;
            List<Team> b = new ArrayList<>(many);
            t0 = System.nanoTime();
            b.sort(Comparator.comparing(Team::name));
            b.sort(Comparator.comparingInt(Team::goalDiff).reversed());
            b.sort(Comparator.comparingInt(Team::points).reversed());
            double three = (System.nanoTime() - t0) / 1e6;
            List<RankedTeam> c = new ArrayList<>(); for (Team t : many) c.add(new RankedTeam(t.name, t.points, t.goalDiff));
            t0 = System.nanoTime(); Collections.sort(c); double comp = (System.nanoTime() - t0) / 1e6;
            if (pass == 2) System.out.printf("Comparator chain (1 sort): %.1f ms | three stable sorts: %.1f ms | Comparable<Team> (1 sort): %.1f ms | chain == three sorts result: %s%n",
                    chain, three, comp, a.toString().equals(b.toString()));
        }
    }

    static List<Team> sorted(List<Team> src, Comparator<Team> c) { List<Team> l = new ArrayList<>(src); l.sort(c); return l; }
}
