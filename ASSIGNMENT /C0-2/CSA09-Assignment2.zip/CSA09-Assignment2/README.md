# CSA09 – Programming in Java – Assignment 2 (CO2: Strings and Collections)

- **Name:** <your name>
- **Register number:** <your register number>
- **Java version used:** OpenJDK 21.0.12 (any JDK 17+ works)

## How to compile and run
Each task has its own folder. From inside the folder:

    javac QxFile.java && java QxFile        (or, single-file mode:  java QxFile.java)

| Folder | Program(s) | Result note |
|---|---|---|
| Q1 | Q1StringBench | `+` is O(n²); StringBuilder/join ~O(n). StringBuffer ≈ StringBuilder + sync cost. Unsynchronised StringBuilder lost data under 16 threads. |
| Q2 | Q2Playlist | ArrayList: O(1) get/append; O(n) front/middle edits. LinkedList: O(1) at ends but O(n) get/middle. ArrayDeque best for the Up Next queue. |
| Q3 | Q3HashContract | Without hashCode: 4 "unique" students; with TODO 1: `Unique students: 2`. Mutating a hashed field loses the element. |
| Q4 | Q4PharmacyMap | HashMap/LinkedHashMap fastest lookup; TreeMap gives code order; Hashtable legacy; sorted array has O(n) insert. |
| Q5 | Q5Leaderboard | Generic `Leaderboard<T>` with comparator chain; subtraction comparator breaks (overflow, TimSort exception). |
| Q6 | Triage, Q6Experiments | PriorityQueue(severity, arrival) gives the hand-verified order; strict priority starves S5; aging key fixes it. |
| Q7 | Q7Redesign | Redesign of the Q2 playlist (ArrayList) as an indexed ring list; validated against ArrayList. |

Each folder contains `output.txt` with the captured run. Add your own output screenshots to each folder, and commit task by task.
