import java.lang.management.ManagementFactory;
import java.util.*;
import java.util.function.Function;

/** Q1 - Railway e-ticket generation: String (+) vs StringBuilder vs StringBuffer (+ join/joiner/format). */
public class Q1StringBench {
    static final com.sun.management.ThreadMXBean MX =
            (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
    static long allocBytes() { return MX.getThreadAllocatedBytes(Thread.currentThread().getId()); }
    static volatile long sink;

    static String[] fields(int n) {
        String[] f = new String[n];
        for (int i = 0; i < n; i++) f[i] = "F" + i + ":VAL" + (i % 10) + "; ";
        return f;
    }

    // ---- the approaches --------------------------------------------------
    static String plus(String[] f)    { String s = ""; for (String x : f) s = s + x; return s; }
    static String builder(String[] f) { StringBuilder b = new StringBuilder(); for (String x : f) b.append(x); return b.toString(); }
    static String buffer(String[] f)  { StringBuffer b = new StringBuffer(); for (String x : f) b.append(x); return b.toString(); }
    static String join(String[] f)    { return String.join("", f); }
    static String joiner(String[] f)  { StringJoiner j = new StringJoiner(""); for (String x : f) j.add(x); return j.toString(); }
    static String format(String[] f)  { return String.format("%s".repeat(f.length), (Object[]) f); }

    static final LinkedHashMap<String, Function<String[], String>> METHODS = new LinkedHashMap<>();
    static {
        METHODS.put("String +", Q1StringBench::plus);
        METHODS.put("StringBuilder", Q1StringBench::builder);
        METHODS.put("StringBuffer", Q1StringBench::buffer);
        METHODS.put("String.join", Q1StringBench::join);
        METHODS.put("StringJoiner", Q1StringBench::joiner);
        METHODS.put("String.format", Q1StringBench::format);
    }

    /** One run = 'tickets' tickets of f.length fields. Returns {avg ms per run, MB allocated per run, MB heap delta}. */
    static double[] measure(Function<String[], String> m, String[] f, int tickets, int warm, int runs) {
        for (int w = 0; w < warm; w++) for (int t = 0; t < tickets; t++) sink += m.apply(f).length();
        System.gc();
        Runtime rt = Runtime.getRuntime();
        long usedBefore = rt.totalMemory() - rt.freeMemory();
        long a0 = allocBytes(), t0 = System.nanoTime();
        for (int r = 0; r < runs; r++) for (int t = 0; t < tickets; t++) sink += m.apply(f).length();
        long t1 = System.nanoTime(), a1 = allocBytes();
        long usedAfter = rt.totalMemory() - rt.freeMemory();
        return new double[]{(t1 - t0) / 1e6 / runs, (a1 - a0) / 1048576.0 / runs, (usedAfter - usedBefore) / 1048576.0};
    }

    static void workload(String name, int tickets, int nFields, int warm, int runs) {
        String[] f = fields(nFields);
        int len = plus(f).length();
        double n = nFields;
        System.out.printf("%n=== %s : %d ticket(s) x %d fields (ticket length %d chars), %d runs averaged ===%n",
                name, tickets, nFields, len, runs);
        System.out.printf("Estimated intermediate String objects with '+' : %,d  | chars copied by '+' : %,.0f | by builder : %,d%n",
                (long) tickets * nFields, tickets * (n * (n + 1) / 2) * (len / n), (long) tickets * len);
        System.out.printf("%-14s %14s %16s %18s%n", "Approach", "avg time (ms)", "alloc/run (MB)", "heap delta (MB)*");
        for (var e : METHODS.entrySet()) {
            double[] r = measure(e.getValue(), f, tickets, warm, runs);
            System.out.printf("%-14s %14.4f %16.3f %18.3f%n", e.getKey(), r[0], r[1], r[2]);
        }
    }

    // ---- thread safety demo ----------------------------------------------
    static void raceDemo() throws Exception {
        System.out.println("\n=== Shared booking log : 16 threads x 200,000 appends of \"ab\" (expected length 6,400,000) ===");
        for (String kind : new String[]{"StringBuilder", "StringBuffer"}) {
            for (int trial = 1; trial <= 5; trial++) {
                final StringBuilder sb = new StringBuilder();
                final StringBuffer sf = new StringBuffer();
                final boolean useBuilder = kind.equals("StringBuilder");
                final int[] errors = {0};
                Thread[] ts = new Thread[16];
                for (int i = 0; i < 16; i++) {
                    ts[i] = new Thread(() -> {
                        try {
                            for (int k = 0; k < 200_000; k++) { if (useBuilder) sb.append("ab"); else sf.append("ab"); }
                        } catch (Throwable ex) { synchronized (errors) { errors[0]++; } }
                    });
                }
                for (Thread t : ts) t.start();
                for (Thread t : ts) t.join();
                int len = useBuilder ? sb.length() : sf.length();
                System.out.printf("%-14s trial %d : length = %,d  lost = %,d  threads-with-exception = %d%n",
                        kind, trial, len, 6_400_000 - len, errors[0]);
            }
        }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("Java " + System.getProperty("java.version") + " | " + System.getProperty("os.name"));
        workload("W1 (short single ticket)", 1, 10, 50_000, 200_000);
        workload("W2 (bulk: 10,000 tickets)", 10_000, 50, 2, 5);
        workload("W3 (own: one very long ticket, e.g. group manifest)", 1, 20_000, 2, 5);

        System.out.println("\n=== Scaling of ONE ticket with the number of fields n (ms per ticket) ===");
        System.out.printf("%8s %12s %14s %10s%n", "n", "String +", "StringBuilder", "ratio");
        double prev = 0;
        for (int n = 1000; n <= 32000; n *= 2) {
            String[] f = fields(n);
            int runs = n <= 4000 ? 200 : 20;
            double a = measure(Q1StringBench::plus, f, 1, runs, runs)[0];
            double b = measure(Q1StringBench::builder, f, 1, runs, runs)[0];
            System.out.printf("%8d %12.4f %14.4f %10.1f   (+ grew x%.2f)%n", n, a, b, a / b, prev == 0 ? 0 : a / prev);
            prev = a;
        }
        raceDemo();
    }
}
