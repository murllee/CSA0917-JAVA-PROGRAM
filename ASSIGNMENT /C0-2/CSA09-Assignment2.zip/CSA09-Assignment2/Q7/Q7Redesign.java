import java.util.*;

/** Q7 - Diagnose, redesign, validate. Chosen solution: Q2 playlist stored in ArrayList (used as playlist + "Up Next" queue). */
public class Q7Redesign {

    /** Redesign: circular-array list with O(1) ends, O(1) get(k) and shifting of the SHORTER side for inserts/removals. */
    static class IndexedRingList<T> {
        private Object[] a = new Object[16];
        private int head = 0, size = 0;
        long moves = 0;                                        // element moves, for operation counting
        private int idx(int i) { return (head + i) & (a.length - 1); }
        private void growIfFull() {
            if (size < a.length) return;
            Object[] b = new Object[a.length * 2];
            for (int i = 0; i < size; i++) b[i] = a[idx(i)];
            a = b; head = 0;
        }
        int size() { return size; }
        @SuppressWarnings("unchecked") T get(int i) { if (i < 0 || i >= size) throw new IndexOutOfBoundsException(); return (T) a[idx(i)]; }
        void addLast(T x) { growIfFull(); a[idx(size)] = x; size++; }
        void addFirst(T x) { growIfFull(); head = (head - 1) & (a.length - 1); a[head] = x; size++; }
        T removeFirst() { T x = get(0); a[head] = null; head = (head + 1) & (a.length - 1); size--; return x; }
        /** Copies logical range [s, s+len) to [d, d+len) (d = s+-1) in at most a few System.arraycopy chunks, wrap-aware. */
        private void move(int s, int d, int len) {
            if (len <= 0) return;
            if (d < s) {                                       // left shift: copy ascending
                int pos = 0;
                while (pos < len) {
                    int ps = idx(s + pos), pd = idx(d + pos);
                    int chunk = Math.min(len - pos, Math.min(a.length - ps, a.length - pd));
                    System.arraycopy(a, ps, a, pd, chunk); pos += chunk;
                }
            } else {                                           // right shift: copy descending
                int pos = len;
                while (pos > 0) {
                    int pe = idx(s + pos - 1), pde = idx(d + pos - 1);
                    int chunk = Math.min(pos, Math.min(pe + 1, pde + 1));
                    System.arraycopy(a, pe - chunk + 1, a, pde - chunk + 1, chunk); pos -= chunk;
                }
            }
            moves += len;
        }
        void add(int i, T x) {
            if (i < 0 || i > size) throw new IndexOutOfBoundsException();
            growIfFull();
            if (i < size / 2) { head = (head - 1) & (a.length - 1); move(1, 0, i); }   // shift front part left
            else move(i, i + 1, size - i);                                             // shift back part right
            a[idx(i)] = x; size++;
        }
        T remove(int i) {
            T x = get(i);
            if (i < size / 2) { move(0, 1, i); a[head] = null; head = (head + 1) & (a.length - 1); }
            else { move(i + 1, i, size - 1 - i); a[idx(size - 1)] = null; }
            size--; return x;
        }
    }

    static volatile long sink;

    // ---------- correctness (differential test against ArrayList) ----------
    static void validate() {
        Random r = new Random(11);
        IndexedRingList<Integer> ring = new IndexedRingList<>(); List<Integer> ref = new ArrayList<>();
        int checked = 0;
        for (int step = 0; step < 300_000; step++) {
            int op = r.nextInt(7), v = r.nextInt();
            switch (op) {
                case 0 -> { ring.addLast(v); ref.add(v); }
                case 1 -> { ring.addFirst(v); ref.add(0, v); }
                case 2 -> { if (!ref.isEmpty()) { if (!ring.removeFirst().equals(ref.remove(0))) throw new AssertionError("removeFirst"); } }
                case 3 -> { int i = r.nextInt(ref.size() + 1); ring.add(i, v); ref.add(i, v); }
                case 4 -> { if (!ref.isEmpty()) { int i = r.nextInt(ref.size()); if (!ring.remove(i).equals(ref.remove(i))) throw new AssertionError("remove"); } }
                case 5, 6 -> { if (!ref.isEmpty()) { int i = r.nextInt(ref.size()); if (!ring.get(i).equals(ref.get(i))) throw new AssertionError("get"); checked++; } }
            }
            if (ring.size() != ref.size()) throw new AssertionError("size");
        }
        for (int i = 0; i < ref.size(); i++) if (!ring.get(i).equals(ref.get(i))) throw new AssertionError("final contents");
        System.out.printf("VALIDATION PASSED: 300,000 random operations, %,d get() checks, final size %,d, contents identical to ArrayList%n", checked, ref.size());
    }

    // ---------- workloads ----------
    /** Up Next: addFirst / addLast / removeFirst in rotation. Returns {ms, elements moved}. */
    static double[] upNextArrayList(int start, int ops) {
        ArrayList<Integer> l = new ArrayList<>(); for (int i = 0; i < start; i++) l.add(i);
        long moved = 0, t0 = System.nanoTime();
        for (int i = 0; i < ops; i++) switch (i % 3) {
            case 0 -> { moved += l.size(); l.add(0, i); }
            case 1 -> l.add(i);
            default -> { moved += l.size() - 1; l.remove(0); }
        }
        return new double[]{(System.nanoTime() - t0) / 1e6, moved};
    }
    static double[] upNextRing(int start, int ops) {
        IndexedRingList<Integer> l = new IndexedRingList<>(); for (int i = 0; i < start; i++) l.addLast(i);
        long t0 = System.nanoTime();
        for (int i = 0; i < ops; i++) switch (i % 3) { case 0 -> l.addFirst(i); case 1 -> l.addLast(i); default -> l.removeFirst(); }
        return new double[]{(System.nanoTime() - t0) / 1e6, l.moves};
    }
    static double upNextLinked(int start, int ops) {
        LinkedList<Integer> l = new LinkedList<>(); for (int i = 0; i < start; i++) l.add(i);
        long t0 = System.nanoTime();
        for (int i = 0; i < ops; i++) switch (i % 3) { case 0 -> l.addFirst(i); case 1 -> l.addLast(i); default -> l.removeFirst(); }
        return (System.nanoTime() - t0) / 1e6;
    }

    /** Mixed editing: 20% addLast, 15% addFirst, 15% removeFirst, 15% insert middle, 10% remove middle, 25% get(k). */
    static int[] script(int ops, long seed) { Random r = new Random(seed); int[] s = new int[ops * 2];
        for (int i = 0; i < ops; i++) { int p = r.nextInt(100); s[2 * i] = p < 20 ? 0 : p < 35 ? 1 : p < 50 ? 2 : p < 65 ? 3 : p < 75 ? 4 : 5; s[2 * i + 1] = r.nextInt(1 << 30); } return s; }

    static double[] mixedList(List<Integer> l, int n, int[] s) {
        for (int i = 0; i < n; i++) l.add(i);
        long moved = 0, t0 = System.nanoTime(); long acc = 0;
        for (int i = 0; i < s.length; i += 2) {
            int sz = l.size();
            switch (s[i]) {
                case 0 -> l.add(i);
                case 1 -> { moved += sz; l.add(0, i); }
                case 2 -> { if (sz > 0) { moved += sz - 1; l.remove(0); } }
                case 3 -> { int k = sz / 2; moved += sz - k; l.add(k, i); }
                case 4 -> { if (sz > 0) { int k = sz / 2; moved += sz - 1 - k; l.remove(k); } }
                default -> { if (sz > 0) acc += l.get(s[i + 1] % sz); }
            }
        }
        sink += acc; return new double[]{(System.nanoTime() - t0) / 1e6, moved};
    }
    static double[] mixedRing(int n, int[] s) {
        IndexedRingList<Integer> l = new IndexedRingList<>(); for (int i = 0; i < n; i++) l.addLast(i);
        long t0 = System.nanoTime(); long acc = 0;
        for (int i = 0; i < s.length; i += 2) {
            int sz = l.size();
            switch (s[i]) {
                case 0 -> l.addLast(i);
                case 1 -> l.addFirst(i);
                case 2 -> { if (sz > 0) l.removeFirst(); }
                case 3 -> l.add(sz / 2, i);
                case 4 -> { if (sz > 0) l.remove(sz / 2); }
                default -> { if (sz > 0) acc += l.get(s[i + 1] % sz); }
            }
        }
        sink += acc; return new double[]{(System.nanoTime() - t0) / 1e6, l.moves};
    }
    /** Append-only playlist: add at end, random get, full iteration. */
    static double[] appendOnly(int n) {
        long t0 = System.nanoTime(); ArrayList<Integer> a = new ArrayList<>(); for (int i = 0; i < n; i++) a.add(i);
        long acc = 0; Random r = new Random(1); for (int i = 0; i < 200_000; i++) acc += a.get(r.nextInt(n)); for (int p = 0; p < 20; p++) for (int x : a) acc += x;
        double ta = (System.nanoTime() - t0) / 1e6;
        t0 = System.nanoTime(); IndexedRingList<Integer> g = new IndexedRingList<>(); for (int i = 0; i < n; i++) g.addLast(i);
        r = new Random(1); for (int i = 0; i < 200_000; i++) acc += g.get(r.nextInt(n)); for (int p = 0; p < 20; p++) for (int i = 0; i < n; i++) acc += g.get(i);
        double tg = (System.nanoTime() - t0) / 1e6; sink += acc; return new double[]{ta, tg};
    }

    public static void main(String[] args) {
        System.out.println("Java " + System.getProperty("java.version"));
        validate();

        System.out.println("\n=== D1. 'Up Next' workload (start 100,000 songs; addFirst/addLast/removeFirst rotation) ===");
        System.out.printf("%10s %16s %18s %14s %16s %14s%n", "ops", "ArrayList ms", "AL elements moved", "RingList ms", "Ring moved", "LinkedList ms");
        for (int pass = 0; pass < 2; pass++) for (int ops : new int[]{15_000, 30_000, 60_000}) {
            double[] a = upNextArrayList(100_000, ops), g = upNextRing(100_000, ops); double l = upNextLinked(100_000, ops);
            if (pass == 1) System.out.printf("%,10d %16.2f %,18.0f %14.2f %,16.0f %14.2f%n", ops, a[0], a[1], g[0], g[1], l);
        }

        System.out.println("\n=== D2. Mixed playlist editing (20% addLast, 15% addFirst, 15% removeFirst, 15% insert-mid, 10% remove-mid, 25% get(k)); 10,000 ops ===");
        System.out.printf("%10s %14s %18s %14s %14s %14s%n", "n", "ArrayList ms", "AL elements moved", "RingList ms", "Ring moved", "LinkedList ms");
        for (int pass = 0; pass < 2; pass++) for (int n : new int[]{10_000, 100_000, 500_000}) {
            int[] s = script(10_000, 5);
            double[] a = mixedList(new ArrayList<>(), n, s), g = mixedRing(n, s), l = mixedList(new LinkedList<>(), n, s);
            if (pass == 1) System.out.printf("%,10d %14.2f %,18.0f %14.2f %,14.0f %14.2f%n", n, a[0], a[1], g[0], g[1], l[0]);
        }

        System.out.println("\n=== D3. Where the ORIGINAL still wins: append-only playlist (build, 200,000 random get, 20 full iterations) ===");
        System.out.printf("%10s %14s %14s%n", "n", "ArrayList ms", "RingList ms");
        for (int pass = 0; pass < 2; pass++) for (int n : new int[]{10_000, 100_000, 500_000}) {
            double[] r = appendOnly(n); if (pass == 1) System.out.printf("%,10d %14.2f %14.2f%n", n, r[0], r[1]);
        }
    }
}
